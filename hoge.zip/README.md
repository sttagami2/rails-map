# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...

## 課題6
### ①課題3のいいね機能を非同期通信を用いて実装しましょう
**前提**
課題3を修了していること
**実装する機能**
* ビュー
  * 投稿一つ一つを部分テンプレートとし、サーバーからのレスポンスで一つのテンプレートを返すこと

### ②課題3のコメント機能を非同期通信を用いて実装しましょう
**前提**
課題3を修了していること
**実装する機能**
* ビュー
  * コメント一つ一つを部分テンプレートとし、サーバーからのレスポンスで一つのテンプレートを返すこと


### <span style="color: #d61b09">③課題4のフォロー・フォロワー機能を非同期通信を用いて実装しましょう</span>
**前提**
課題4を修了していること
**実装する機能**
* ビュー
  * フォローした時, 外した時にフォロー数, フォロワー数も変更すること